﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BallScript : MonoBehaviour
{
    private bool ballIsActive;
    private Vector3 ballPosition;
    private Vector3 ballInitialForce;

    private Rigidbody rigidbody;

    public float speed = 10f;
    public float maxSpeed = 350f;
    private bool upSpeed = false;
    
    public GameObject playerObject;

    public GameObject forRot;
    public float speedRot = 1f;
    private bool timeRot = false;

    public GameObject StartPanel;

    public Text win;
    public int winCoine;

    public Text lose;
    public int loseCoine;


    void Start()
    {
        rigidbody = GetComponent<Rigidbody>();
        
        ballInitialForce = new Vector3(250.0f, 0f, 600.0f);
        
        ballIsActive = false;
        
        ballPosition = transform.position;

        StartPanel.SetActive(true);
    }

    void OnCollisionEnter(Collision collision)
    {
        if(ballPosition.x >= 9)
        {
            rigidbody.AddForce(new Vector3(0f, 0f, speed));
        }

        if (ballPosition.x <= -7)
        {
            rigidbody.AddForce(new Vector3(0f, 0f, -speed));
        }


        if(collision.gameObject.tag == "Player")
        {
            winCoine = winCoine + 1; 
        }

        if (collision.gameObject.tag == "Finish")
        {
            loseCoine = loseCoine + 1;
        }
    }

    private void FixedUpdate()
    {
        win.text = winCoine.ToString();

        lose.text = loseCoine.ToString();
    }


    void Update()
    {
        Rotation_Ball();

        ballPosition = transform.position;

        if (upSpeed == true)
        {
            if (speed <= maxSpeed)
            {
                speed = speed += Time.deltaTime * 20;
            }

            if (speed >= maxSpeed)
            {
                upSpeed = false;
            }
        }

        
        if (Input.GetButtonDown("Fire1") == true)
        {
            if (!ballIsActive)
            {
                rigidbody.isKinematic = false;
                
                rigidbody.AddForce(ballInitialForce);
                
                ballIsActive = !ballIsActive;

                upSpeed = true;

                timeRot = true;

                StartPanel.SetActive(false);
            }
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        if (!ballIsActive && playerObject != null)
        {
            
            ballPosition.x = playerObject.transform.position.x;
            
            transform.position = ballPosition;
        }
        
        if (ballIsActive && transform.position.y < -6)
        {
            ballIsActive = !ballIsActive;
            ballPosition.x = playerObject.transform.position.x;
            ballPosition.y = -4.2f;
            transform.position = ballPosition;

            rigidbody.isKinematic = true;
        }

    }

    void Rotation_Ball()
    {
        if (timeRot == true)
        {
            forRot.transform.rotation *= Quaternion.Euler(0f, speedRot, 0f);

            if (speedRot <= 25)
            {
                speedRot = speedRot += Time.deltaTime;
            }
        }

        if (timeRot == false)
        {
            forRot.transform.rotation *= Quaternion.Euler(0f, 1, 0f);
        }
    }
}
