﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCurrent : MonoBehaviour
{
    private float mouseX;

    private Vector3 playerPosition;

    private Vector3 MouseAll;

    public float boundary = 8.5f;

    public float horizonSpeed = 2f;


    private void Start()
    {
        playerPosition = gameObject.transform.position;

        //MouseAll = Input.mousePosition;
    }

    private void Update()
    {
        //Varian_1();

        //Variant_2();

        Variant_3();
    }

    void Varian_1()
    {
        mouseX = Input.GetAxis("Mouse X");

        if (mouseX != 0)
        {
            playerPosition = new Vector3(mouseX, 1f, -8.5f);
            transform.position = playerPosition;
        }

        if (playerPosition.x < -boundary)
        {
            transform.position = new Vector3(-boundary, playerPosition.y, playerPosition.z);
        }
        if (playerPosition.x > boundary)
        {
            transform.position = new Vector3(boundary, playerPosition.y, playerPosition.z);
        }
    }


    void Variant_2()
    {
        MouseAll = Input.mousePosition;
        MouseAll.x = MouseAll.x * 0.1f;


        playerPosition = new Vector3(MouseAll.x, 1f, -8.5f);
        transform.position = playerPosition;


        if (playerPosition.x < -boundary)
        {
            transform.position = new Vector3(-boundary, playerPosition.y, playerPosition.z);
        }
        if (playerPosition.x > boundary)
        {
            transform.position = new Vector3(boundary, playerPosition.y, playerPosition.z);
        }
    }

    void Variant_3()
    {
        playerPosition.x += Input.GetAxis("Mouse X") * horizonSpeed;

        transform.position = playerPosition;

        if (playerPosition.x < -boundary)
        {
            transform.position = new Vector3(-boundary, playerPosition.y, playerPosition.z);
        }
        if (playerPosition.x > boundary)
        {
            transform.position = new Vector3(boundary, playerPosition.y, playerPosition.z);
        }
    }
}
